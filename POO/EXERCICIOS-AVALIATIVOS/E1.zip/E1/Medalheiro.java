import java.util.Collection;
import java.util.ArrayList;

// classe catálogo que gerencia o cadastro de medalhas:
public class Medalheiro {

	private ArrayList<Medalha> medalhas;

	

	public boolean cadastraMedalha(Medalha medalha) {

	}

}
