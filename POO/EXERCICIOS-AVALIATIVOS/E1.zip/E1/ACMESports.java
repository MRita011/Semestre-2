
// Imports
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.PrintStream;
import java.nio.charset.Charset;
import java.util.Locale;
import java.util.Scanner;

public class ACMESports {

	private Medalheiro medalheiro;
	private Plantel plantel;

	// Atributos para redirecionamento de E/S
	private Scanner in = new Scanner(System.in); // Atributo para entrada de dados
	private PrintStream saidaPadrao = System.out; // Guarda a saida padrao - tela (console)
	private final String nomeArquivoEntrada = "dadosin.txt"; // Nome do arquivo de entrada de dados
	private final String nomeArquivoSaida = "dadosout.txt"; // Nome do arquivo de saida de dados

	public ACMESports() {
		medalheiro = new Medalheiro();
		plantel = new Plantel();

		redirecionaES(); // Redireciona E/S para arquivos
	}

	public void executar() {
		cadastrarAtletas();
		cadastrarMedalhas();
		cadastrarMedalhasAtletasCorrespondentes();

		MostrarAtletaPorNome();
		MostrarAtletaPorPais();
		MostrarAtletaPorMedalha();
	}

	public void cadastrarAtletas() {
		// lê todos os dados de cada atleta e, se o número não for repetido, cadastra-o
		// no sistema.
		// Para cada atleta cadastrado com sucesso no sistema, mostra os dados do atleta
		// no formato: 1:número,nome,país

		String nome;
		String pais;
		int numero;

		atleta = entrada.nextLine();
		while(!numero == -1) {
			
		}

	}

	public void cadastrarMedalhas() {
	}

	public void cadastrarMedalhasAtletasCorrespondentes() {
	}

	public void MostrarAtletaPorNome() {
	}

	public void MostrarAtletaPorPais() {
	}

	public void MostrarAtletaPorMedalha() {
	}

	// Redireciona E/S para arquivos
	// Chame este metodo para redirecionar a leitura e escrita de dados para
	// arquivos
	private void redirecionaES() {
		try {
			BufferedReader streamEntrada = new BufferedReader(new FileReader(nomeArquivoEntrada));
			entrada = new Scanner(streamEntrada); // Usa como entrada um arquivo
			PrintStream streamSaida = new PrintStream(new File(nomeArquivoSaida), Charset.forName("UTF-8"));
			// System.setOut(streamSaida); // Usa como saida um arquivo
		} catch (Exception e) {
			System.out.println(e);
		}
		Locale.setDefault(Locale.ENGLISH); // Ajusta para ponto decimal
		entrada.useLocale(Locale.ENGLISH); // Ajusta para leitura para ponto decimal
	}

	// Restaura E/S padrao de tela(console)/teclado
	// Chame este metodo para retornar a leitura e escrita de dados para o padrao
	private void restauraES() {
		System.setOut(saidaPadrao);
		entrada = new Scanner(System.in);
	}
}