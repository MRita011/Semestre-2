// classe que representa um atleta da competição:

public class Atleta {

	private int numero;
	private String nome;
	private String pais;

	public Atleta(int numero, String nome, String pais) {
		numero = this.numero;
		nome = this.nome;
		pais = this.pais;
	}

	public int getNumero() {
		return numero;
	}

	public String getNome() {
		return nome;
	}

	public String getPais() {
		return pais;
	}

	// : adiciona uma nova medalha ao atleta
	public void adicionaMedalha(Medalha medalha) {

	}

	// retorna a quantidade de medalhas do atleta.
	public int consultaQuantidadeMedalhas() {
		return 0;
	}

}
