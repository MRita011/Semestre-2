// classe que representa uma medalha da competição:

public class Medalha {

	private int codigo;
	private int tipo;
	private boolean individual; // medalha é individual (true) ou equipe (false)
	private String modalidade; // nome do esporte

	public Medalha(int codigo, int tipo, boolean individual, String modalidade) {
		codigo = this.codigo;
		tipo = this.tipo;
		individual = this.individual;
		modalidade = this.modalidade;
	}

	public int getCodigo() {
		return codigo;
	}

	public int getTipo() {
		return tipo;
	}

	public boolean getIndividual() {
		return individual;
	}

	public String getModalidade() {
		return modalidade;
	}

	// adiciona um atleta à medalha.
	public void adicionaAtleta(Atleta atleta) {
		
	}

}
