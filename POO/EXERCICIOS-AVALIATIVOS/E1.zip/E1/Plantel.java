// classe catálogo que gerencia o cadastro de atletas:

import java.util.ArrayList;
import java.util.Collection;

public class Plantel 
{
	private ArrayList<Atleta> atletas;

	public Plantel() {
		atletas = new ArrayList<Atleta>();
	}

	// recebe como parâmetro um novo Atleta e o cadastra no sistema.
	// não pode haver atletas com o mesmo número.
	// retorna true se o cadastro teve sucesso; ou false em caso contrário.

	public boolean cadastraAtleta(Atleta atleta) {
		if (consultaAtleta(atletas.getNumero() != null))
			return false;

		return atletas.add(atleta);
	}


	// retorna o atleta com o nome indicado. Se não houver nenhum atleta com este
	// nome retorna null.

	public Atleta consultaAtleta(String nome) {
		for (Atleta atleta : atletas) {
			if (atleta.getNome().equals(nome))
				return atleta;
		}
		return null;
	}


	// retorna o atleta com o número indicado. Se não houver nenhum atleta com este
	// número retorna null.
	
	public Atleta consultaAtleta(int numero) {
		for (Atleta atleta : atletas) {
			if (atleta.getNumero() == numero)
				return atleta;
		}
		return null;
	}
}
