import app.*;

public class Main {
    public static void main(String[] args) {
		ACMEMidia acme = new ACMEMidia();
		acme.executa();
    }
}
