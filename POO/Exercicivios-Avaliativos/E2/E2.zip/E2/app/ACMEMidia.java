package app;

// Imports

import dados.*;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.PrintStream;
import java.nio.charset.Charset;
import java.util.InputMismatchException;
import java.util.Locale;
import java.util.Scanner;
import java.util.List;

public class ACMEMidia {
    private final String nomeArquivoEntrada = "entrada.txt";
    private final String nomeArquivoSaida = "saida.txt";
    private Scanner entrada = new Scanner(System.in);
    private PrintStream saidaPadrao = System.out;
    private Midiateca midiateca;

    public ACMEMidia() {
        redirecionaES();
        this.midiateca = new Midiateca();
    }

    public void executa() {
        cadastrarVideos();
        cadastrarMusicas();
        mostrarDadosPorMidia();
        mostrarDadosPorCategoria();
        mostrarDadosPorQualidade();
        mostrarMusicaMaiorDuracao();
        removerMidia();
        mostrarSomatorioLocacao();
    }

    public void cadastrarVideos() {
        //  Cadastrar vídeos: lê todos os dados de cada vídeo e, se o código não for repetido no sistema, cadastra-o no sistema.
        //  Se o código da vídeo for repetido mostra a mensagem no formato: 1:Erro-video com codigo repetido: codigo
        //  Para cada vídeo cadastrado com sucesso no sistema, mostra os dados da vídeo no formato: 1:codigo,titulo,ano,categoria,qualidade

        int codigo;
        String titulo;
        int ano;
        Categoria categoria;
        int qualidade;

        try {
            codigo = entrada.nextInt();
            entrada.nextLine();

            while (codigo != -1) {
                titulo = entrada.nextLine();
                ano = entrada.nextInt();
                entrada.nextLine();
                categoria = Categoria.valueOf(entrada.nextLine());
                qualidade = entrada.nextInt();
                entrada.nextLine();

                Midia midia = new Video(codigo, titulo, ano, categoria, qualidade);
                if (midiateca.cadastraMidia(midia))
                    System.out.println("1:" + midia.getCodigo() + "," + midia.getTitulo() + "," + midia.getAno() + "," + categoria.getNome() + "," + ((Video) midia).getQualidade());
                else
                    System.out.println("1:Erro-video com codigo repetido: " + codigo);

                codigo = entrada.nextInt();
                entrada.nextLine();
            }
        } catch (InputMismatchException e) {
            System.out.println("Erro de formato de entrada. Verifique os dados e tente novamente.");
            entrada.nextLine();
        } catch (Exception e) {
            System.out.println("Erro ao cadastrar vídeo: " + e.getMessage());
            entrada.nextLine();
        }
    }

    public void cadastrarMusicas() {
        //  Cadastrar músicas: lê todos os dados de cada música e, se o código não for repetido no sistema, cadastra-a no sistema.
        //  Se o código da música for repetido mostra a mensagem no formato: 2:Erro-musica com codigo repetido:codigo.
        //  Para cada música cadastrada com sucesso no sistema, mostra os dados da música no formato: 2:codigo,titulo,ano,categoria,duração

        int codigo;
        String titulo;
        int ano;
        Categoria categoria;
        double duracao;

        try {
            codigo = entrada.nextInt();
            entrada.nextLine();

            while (codigo != -1) {
                titulo = entrada.nextLine();
                ano = entrada.nextInt();
                entrada.nextLine();
                categoria = Categoria.valueOf(entrada.nextLine());
                duracao = entrada.nextDouble();
                entrada.nextLine();

                Midia midia = new Musica(codigo, titulo, ano, categoria, duracao);
                if (midiateca.cadastraMidia(midia))
                    System.out.println("2:" + midia.getCodigo() + "," + midia.getTitulo() + "," + midia.getAno() + "," + categoria.getNome() + "," + ((Musica) midia).getDuracao());
                else
                    System.out.println("2:Erro-musica com codigo repetido: " + codigo);

                codigo = entrada.nextInt();
                entrada.nextLine();
            }
        } catch (InputMismatchException e) {
            System.out.println("Erro de formato de entrada. Verifique os dados e tente novamente.");
            entrada.nextLine();
        } catch (Exception e) {
            System.out.println("Erro ao cadastrar vídeo: " + e.getMessage());
            entrada.nextLine();
        }
    }

    public void mostrarDadosPorMidia() {
        //  Mostrar os dados de uma determinada mídia: lê o código de uma mídia.
        //  Se não existir uma mídia com o código indicado, mostra a mensagem de erro: 3:Codigo inexistente.
        //  Se existir, mostra os dados da mídia no formato: 3:atributo1,atributo2,atributo3,...,valor da locação

        try {
            int codigo = entrada.nextInt();
            entrada.nextLine();

            Midia midia = midiateca.consultaPorCodigo(codigo);
            if (midia == null)
                System.out.println("3: Codigo inexistente.");
            else
                System.out.println("3:" + midia + "," + midia.calculaLocacao());

        } catch (InputMismatchException e) {
            System.out.println("Entrada inválida. Por favor, insira um código válido.");
        } catch (Exception e) {
            System.out.println("Ocorreu um erro inesperado: " + e.getMessage());
            e.printStackTrace();
        }
    }

    public void mostrarDadosPorCategoria() {
        //  Mostrar os dados de mídia(s) de uma determinada categoria: lê a categoria de uma mídia.
        //  Se não existir uma mídia com a categoria indicada, mostra a mensagem de erro: 4:Nenhuma midia encontrada.
        //  Se existir, mostra os dados da(s) mídia(s) no formato:4:atributo1,atributo2,atributo3,...,valor da locação

        try {
            Categoria categoria = Categoria.valueOf(entrada.nextLine());

            List<Midia> midias = midiateca.consultaPorCategoria(categoria);
            if (midias == null || midias.isEmpty())
                System.out.println("4:Nenhuma mídia encontrada.");

            else {
                for (Midia midia : midias)
                    System.out.println("4:" + midia + "," + midia.calculaLocacao());
            }

        } catch (IllegalArgumentException e) {
            System.out.println("Categoria inválida. Por favor, insira uma categoria válida.");
        } catch (Exception e) {
            System.out.println("Ocorreu um erro inesperado: " + e.getMessage());
            e.printStackTrace();
        }
    }

    public void mostrarDadosPorQualidade() {
        //  Mostrar os dados de vídeo(s) de uma determinada qualidade: lê a qualidade de vídeo.
        //  Se não existir a qualidade indicada, mostra a mensagem de erro: 5:Qualidade inexistente.
        //  Se existir, mostra os dados do(s) vídeos(s) no formato: 5:atributo1,atributo2,atributo3,...,valor da locação

        try {
            int qualidade = entrada.nextInt();
            entrada.nextLine();

            List<Video> videos = midiateca.consultaPorQualidade(qualidade);
            if (videos == null || videos.isEmpty())
                System.out.println("5:Qualidade inexistente.");
            else {
                for (Video video : videos) {
                    System.out.println("5:" + video + "," + video.calculaLocacao());
                }
            }
        } catch (InputMismatchException e) {
            System.out.println("Entrada inválida. Por favor, insira uma qualidade válida.");
        } catch (Exception e) {
            System.out.println("Ocorreu um erro inesperado: " + e.getMessage());
            e.printStackTrace();
        }
    }

    public void mostrarMusicaMaiorDuracao() {
        //  Mostrar os dados da música de maior duração: localiza a música cadastrada com maior duração.
        //  Se não existir nenhuma música cadastrada, mostra a mensagem de erro: 6:Nenhuma música encontrada.
        //  Se existir, mostra os dados da música no formato: 6:titulo,duracao

        try {
            Musica musicaMD = null;
            double maiorDuracao = Double.MIN_VALUE;

            for (Midia midia : midiateca.getMidias()) {
                if (midia instanceof Musica) {
                    Musica musica = (Musica) midia;
                    if (musica.getDuracao() > maiorDuracao) {
                        maiorDuracao = musica.getDuracao();
                        musicaMD = musica;
                    }
                }
            }

            if (musicaMD != null)
                System.out.println("6:" + musicaMD.getTitulo() + "," + musicaMD.getDuracao());
            else
                System.out.println("6:Nenhuma música encontrada.");

        } catch (Exception e) {
            System.out.println("Ocorreu um erro inesperado: " + e.getMessage());
            e.printStackTrace();
        }
    }

    public void removerMidia() {
        //  Remover uma mídia: lê o código de uma mídia.
        //  Se não existir uma mídia com o código indicado, mostra a mensagem de erro: 7:Codigo inexistente.
        //  Se existir, mostra os dados da mídia no formato: 7:atributo1,atributo2,atributo3,...,valor da locação e depois a remove do sistema

        try {
            int codigo = entrada.nextInt();

            Midia midia = midiateca.consultaPorCodigo(codigo);
            if (midia == null)
                System.out.println("7:Codigo inexistente.");

            else {
                System.out.println("7:" + midia + "," + midia.calculaLocacao());
                midiateca.removeMidia(codigo);
            }
        } catch (InputMismatchException e) {
            System.out.println("Entrada inválida. Por favor, insira um código válido.");
        } catch (Exception e) {
            System.out.println("Ocorreu um erro inesperado: " + e.getMessage());
            e.printStackTrace();
        }
    }

    public void mostrarSomatorioLocacao() {
        //  Mostrar o somatório de locações de todas as mídias: calcula o somatório do valor de locação de todas as mídias do sistema.
        //  Se não existir mídia cadastrada no sistema, mostra a mensagem de erro: 8:Nenhuma midia encontrada.
        //  Se existir, mostra a mensagem no formato: 8:valor do somatório

        try {
            double somatorioLocacao = 0.0;

            List<Midia> midias = midiateca.getMidias();
            if (midias == null || midias.isEmpty())
                System.out.println("8:Nenhuma mídia encontrada.");

            for (Midia midia : midias) {
                somatorioLocacao += midia.calculaLocacao();
            }
            System.out.printf("8:" + somatorioLocacao);

        } catch (Exception e) {
            System.out.println("Ocorreu um erro inesperado: " + e.getMessage());
            e.printStackTrace();
        }
    }

    private void redirecionaES() {
        try {
            BufferedReader streamEntrada = new BufferedReader(new FileReader("entrada.txt"));
            entrada = new Scanner(streamEntrada);
            PrintStream streamSaida = new PrintStream(new File("saida.txt"), Charset.forName("UTF-8"));
            System.setOut(streamSaida);
        } catch (Exception e) {
            System.out.println(e);
        }
        Locale.setDefault(Locale.ENGLISH);
        entrada.useLocale(Locale.ENGLISH);
    }

    private void restauraES() {
        System.setOut(saidaPadrao);
        entrada = new Scanner(System.in);
    }
}