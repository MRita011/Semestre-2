package dados;

public class Musica extends Midia {
    private double duracao;

    public Musica(int codigo, String titulo, int ano, Categoria categoria, double duracao) {
        super(codigo, titulo, ano, categoria);
        this.duracao = duracao;
    }

    public double getDuracao() {
        return duracao;
    }

    @Override
    public double calculaLocacao() {
        double locacao;

        switch (getCategoria()) {
            case ACA:
                locacao = duracao * 0.90;
                break;

            case DRA:
                locacao = duracao * 0.70;
                break;

            case FIC:
                locacao = duracao * 0.50;
                break;

            case ROM:
                locacao = duracao * 0.30;
                break;

            default:
                locacao = 0.0;
        }

        double casasDecimais = locacao * 100 - Math.floor(locacao * 100);
        if (casasDecimais > 0.01)
            return Math.ceil(locacao * 100) / 100;

        else
            return locacao;
    }

    @Override
    public String toString() {
        return super.toString() + duracao;
    }
}
