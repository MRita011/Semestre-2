package dados;

import java.util.ArrayList;
import java.util.List;
import java.util.NoSuchElementException;

public class Midiateca implements Iterador {
    private int contador;
    private List<Midia> midias;

    public Midiateca() {
        this.midias = new ArrayList<>();
        this.contador = 0;
    }

    public List<Midia> getMidias() {
        return midias;
    }

    public boolean cadastraMidia(Midia midia) {
        for (Midia m : midias) {
            if (m.getCodigo() == midia.getCodigo()) {
                return false; // Código repetido
            }
        }
        midias.add(midia);
        return true;
    }

    public Midia consultaPorCodigo(int codigo) {
        for (Midia m : midias) {
            if (m.getCodigo() == codigo) {
                return m;
            }
        }
        return null;
    }

    public List<Midia> consultaPorCategoria(Categoria categoria) {
        List<Midia> result = new ArrayList<>();
        for (Midia m : midias) {
            if (m.getCategoria() == categoria) {
                result.add(m);
            }
        }
        return result;
    }

    public boolean removeMidia(int codigo) {
        for (Midia m : midias) {
            if (m.getCodigo() == codigo) {
                midias.remove(m);
                return true;
            }
        }
        return false;
    }

    public List<Video> consultaPorQualidade(int qualidade) {
        List<Video> videosEncontrados = new ArrayList<>();
        for (Midia m : midias) {
            if (m instanceof Video) {
                Video video = (Video) m;
                if (video.getQualidade() == qualidade)
                    videosEncontrados.add(video);
            }
        }
        return videosEncontrados.isEmpty() ? null : videosEncontrados;
    }

    @Override
    public void reset() {
        contador = 0;
    }

    @Override
    public boolean hasNext() {
        return contador < midias.size();
    }

    @Override
    public Object next() {
        if (hasNext())
            return midias.get(contador++);

        else
            throw new NoSuchElementException("Não há mais elementos");
    }
}
