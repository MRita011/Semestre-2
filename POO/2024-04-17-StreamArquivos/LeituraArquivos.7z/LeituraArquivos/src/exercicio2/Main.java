package exercicio2;

public class Main {
    public static void main(String[] args) {
        LeituraArquivoTextoEstruturado leitura = new LeituraArquivoTextoEstruturado();
        leitura.leArquivoTextoEstruturado("CADASTRO.TXT");
    }
}