package exercicio2;

import java.io.BufferedReader;
import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

public class LeituraArquivoTextoEstruturado {
    public void leArquivoTextoEstruturado(String nomeArquivo) {

//       O arquivo CADASTRO.TXT possui informações de cadastro de pessoas com a seguinte estrutura:
//       Codigo_da_pessoa : Nome_da_pessoa

        Path path1 = Paths.get("CADASTRO.TXT");
        try (BufferedReader reader = Files.newBufferedReader(path1, Charset.defaultCharset())) {
            String line = null;
            int numLinha = 0;
            while ((line = reader.readLine()) != null) {
                numLinha++;
                System.out.println("Linha " + numLinha + ": " + line);
            }
        } catch (IOException e) {
            System.err.format("Erro de E/S: %s%n", e);
        }

    }
}

