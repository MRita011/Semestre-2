package exercicio1;

public class Main {
    public static void main(String[] args) {
        LeituraArquivoTexto leitura = new LeituraArquivoTexto();
        leitura.leArquivoTexto();
    }
}