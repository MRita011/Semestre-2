package exercicio1;

import java.io.BufferedReader;
import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

public class LeituraArquivoTexto {

    public void leArquivoTexto() {
        Path path1 = Paths.get("NOMES.TXT");
        try (BufferedReader reader = Files.newBufferedReader(path1, Charset.defaultCharset())) {
            String line = null;
            int numLinha = 0;
            while ((line = reader.readLine()) != null) {
                numLinha++;
                System.out.println("Linha " + numLinha + ": " + line);
            }
        } catch (IOException e) {
            System.err.format("Erro de E/S: %s%n", e);
        }

    }
}
