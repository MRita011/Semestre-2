// SEMANA 6: 16/03
// Maria Rita e Alexya

public class Main
{
    public static void main(String[] args) {
        Skynet app = new Skynet();
        app.executar();
    }
}