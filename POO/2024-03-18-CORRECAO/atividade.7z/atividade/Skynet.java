// Imports
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.PrintStream;
import java.nio.charset.Charset;
import java.util.Locale;
import java.util.Scanner;

public class Skynet
{
    private final Enxame enxame;

    // Atributos para redirecionamento de E/S
    private Scanner in = new Scanner(System.in);  // Atributo para entrada de dados
    private PrintStream saidaPadrao = System.out;   // Guarda a saida padrao - tela (console)
    private final String nomeArquivoEntrada = "dadosin.txt";  // Nome do arquivo de entrada de dados
    private final String nomeArquivoSaida = "dadosout.txt";  // Nome do arquivo de saida de dados

    public Skynet() {
        enxame = new Enxame();
        redirecionaES();    // Redireciona E/S para arquivos
    }

    public void executar() {
        cadastrarRobo();
        mostrarSomatorio();
        mostrarRobo();
    }

    public void cadastrarRobo() {
        String modelo;
        double valor;
        modelo = in.nextLine();

        while (!modelo.equals("-1")) {
            valor = in.nextDouble();
            in.nextLine();

            Robo r = new Robo(modelo, valor);
            enxame.adicionaRobo(r);

            modelo = in.nextLine(); // ler próximo modelo
        }
    }

    private void mostrarSomatorio() {

    }

    private void mostrarRobo() {

    }

    // Redireciona E/S para arquivos
    // Chame este metodo para redirecionar a leitura e escrita de dados para arquivos
    private void redirecionaES() {
        try {
            BufferedReader streamEntrada = new BufferedReader(new FileReader("dadosin.txt"));
            in = new Scanner(streamEntrada);   // Usa como entrada um arquivo
            PrintStream streamSaida = new PrintStream(new File("dadosout.txt"), Charset.forName("UTF-8"));
            System.setOut(streamSaida);             // Usa como saida um arquivo
        } catch (Exception e) {
            System.out.println(e);
        }
        Locale.setDefault(Locale.ENGLISH);   // Ajusta para ponto decimal
        in.useLocale(Locale.ENGLISH);   // Ajusta para leitura para ponto decimal
    }

    // Restaura E/S padrao de tela(console)/teclado
    // Chame este metodo para retornar a leitura e escrita de dados para o padrao
    private void restauraES() {
        System.setOut(saidaPadrao);
        in = new Scanner(System.in);
    }
}