import java.util.ArrayList;

public class Enxame
{
    private ArrayList<Robo> robos;

    public Enxame() {
        robos = new ArrayList<Robo>();
    }

    // --------- CREATE --------- //
    public boolean adicionaRobo(Robo robo) {
        if (consultaRobo(robo.getModelo()) != null) {
            return false;
        }
        robos.add(robo);
            return true;
    }

    // --------- RETRIEVE --------- //

    public Robo consultaRobo(String modelo) {
        if (!robos.isEmpty()) {
            for (Robo r :  robos) {
                if (r.getModelo().equals(modelo))
                    return r;
            }
        }
        return null;
    }

    public double calculaSomatorio() {
        double somatorio = 0.0;

        for (int i = 0; i < robos.size(); i++) {
            Robo r = robos.get(i);
            somatorio += r.getValor();
        }
        return somatorio;
    }
}