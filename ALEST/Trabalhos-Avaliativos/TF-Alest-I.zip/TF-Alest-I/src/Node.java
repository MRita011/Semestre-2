public class Node {
    public Integer element;
    public Node left;
    public Node right;
}
